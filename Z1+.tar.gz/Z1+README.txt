This software can be obtained from mk@mat.ethz.ch or the CPC library and should not be re-distributed. 

For an extended documentation and references see below.
Please contact mk@mat.ethz.ch for suggestions. 

__________________________

Pre-requisites: 
__________________________

To install and run Z1+ under linux or unix, you need to have perl installed (check via: which perl), 
and a fortran compiler such as gfortran or ifort (check via: which gfortran or which ifort). It is
possible that Z1+ also runs under windows subject to minor changes, but I never tried.

__________________________

Installation notes: 
__________________________

1) Unpack Z1+.tar in a fresh directory
2) perl Z1+install.pl or perl ./Z1+install.pl
   If successful, a perl script Z1+ has been generated.
3) Copy this Z1+ script to another location, where it will be used, or where it can be found (such as your local bin directory) 

Some test configurations named .benchmark-XX.Z1 are available within the installation directory.

__________________________

Documentation 
__________________________

1) Execute Z1+ (without any arguments) to show a list of available options
2) Resulting files described below
3) Read the related publication
__________________________

How to run Z1+
__________________________

Some Z1-formatted test configurations named .benchmark-XX.Z1 are available within the installation directory.
You may alternatively use lammps dump or data files as input files. To run Z1+ on your configuration, call 

Z1+ <configuration-file>

__________________________

Resulting file Z1+summary.dat (summary of results, per chain information contained in files below)
If Z1+ is called with the -t or -p option, the resulting files are instead named PPA-summary.dat or PPA+summary.dat
__________________________

One line per snapshot

.......... ................................................................... 
Column no : quantity
.......... ...................................................................
1         : time step (if available)
2         : number of true chains = chains with more than 2 beads per chain
3         : mean number of beads per original chain
4         : mean squared end-to-end distance
5         : mean contour length per chain of the shortest path = <Lpp>
6         : mean number of entanglements per chain
7         : coil tube diameter (app)
8         : coil tube step length (bpp)
9         : square root of mean squared contour length per chain = sqrt(<Lpp^2>)
10        : classical kink Ne-estimator = Ne_CK
11        : modified kink Ne-estimator = Ne_MK
12        : classical coil Ne-estimator = Ne_CC
13        : modified coil Ne-estimator = Ne_MC
14        : mean bond length of the original chain
15        : bead number density of the original configuration
.............................................................................

__________________________

Resulting file Z1+SP.dat 
__________________________

For each snapshot: 
    - number of chains (M)
    - linear box sizes (boxx,boxy,boxz)
    For each of the M chains: 
        - number (NSP) of shortest path nodes of chain
        Followed by NSP rows: 
            - x y z s E 
            or 
            - x y z s E chain node

where 
x,y,z   : node coordinate of shortest path
s       : corresponding bead number on original chain 
E       : 1: entanglement point or 0: chain end
chain   : chain number responsible for the entanglement point (generated if Z1+ is called with the + option)
node    : node number on this chain (generated if Z1+ is called with the + option)

__________________________

Resulting file Z1+initconfig.dat
__________________________

For each snapshot:
    - number of chains (M)
    - linear box sizes (boxx,boxy,boxz)
    For each of the M chains:
        - number (N) of beads of original chain
        Followed by NSP rows:
            - x y z

where
x,y,z   : bead coordinates of original chain

__________________________

Resulting file Ree_values.dat
__________________________

One line per snapshot: nth column carries end-to-end distance of nth chain

__________________________

Resulting file Lpp_values.dat
__________________________

One line per snapshot: nth column carries contour length of shortest path of nth chain

__________________________

Resulting file N_values.dat
__________________________

One line per snapshot: nth column carries number of beads of original nth chain

__________________________

Resulting file Z_values.dat
__________________________

One line per snapshot: nth column carries number of entanglements of nth chain

__________________________

Resulting file log.Z1
__________________________

Generated if Z1+ is called with the -l option.

__________________________

Resulting file PPA.dat
__________________________

Generated if Z1+ is called with the -t option. 
The file format is identical with Z1+initconfig.dat

__________________________

Resulting file PPA+.dat
__________________________

Generated if Z1+ is called with the -p option.
The file format is identical with Z1+initconfig.dat

__________________________

Publications, documentation
__________________________

@article{Zcode,
    author  = {M. Kr\"oger},
    title   = {Shortest multiple disconnected path for the analysis of entanglements in two- and three-dimensional polymeric systems},
    journal = {Comput. Phys. Commun.},
    volume  = {168},
    pages   = {209-232},
    year    = {2005}
}

@article{Shanbhag2007,
    author  = {S. Shanbhag and M. Kr\"oger},
    title   = {Primitive path networks generated by annealing and geometrical methods: Insights into differences},
    journal = {Macromolecules},
    volume  = {40},
    pages   = {2897-2903},
    year    = {2007}
}

@article{Hoy2009,
    author  = {R. S. Hoy and K. Foteinopoulou and M. Kr\"oger},
    title   = {Topological analysis of polymeric melts: Chain-length effects and fast-converging estimators for entanglement length},
    journal = {Phys. Rev. E},
    volume  = {80},
    pages   = {031803},
    year    = {2009}
}

@article{Karayiannis2009,
    author  = {N. C. Karayiannis and M. Kr\"oger},
    title   = {Combined molecular algorithms for the generation, equilibration and topological analysis of entangled polymers: Methodology and performance},
    journal = {Int. J. Mol. Sci.},
    volume  = {10},
    pages   = {5054-5089},
    year    = {2009}
}

@article{Z1+,
    title   = {The Z1+ package: Shortest multiple disconnected path for the analysis of entanglements in macromolecular systems},
    journal = {Comput. Phys. Commun.},
    year    = {2022},
    pages   = {submitted 21 June 2022}
}




