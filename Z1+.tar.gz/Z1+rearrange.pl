#! /usr/bin/perl

# (c) 25 Nov 2021 mk@mat.ethz.ch 

# Copyright 2022 Martin Kroger
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#   http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

sub strip { chomp $_[0]; $_[0]=~s/^\s+//g; $_[0]=~s/\s+$//; $_[0]=~s/\s+/ /g; $_[0]; }; 

foreach $file ('N_values.dat','Lpp_values.dat','Z_values.dat','Ree_values.dat') {
 `cp $file .$file`;  
 open(D,"<.$file"); open(N,">$file"); 
 open(Y,"<$ARGV[0]"); 
 while (!eof(Y)) { $line=<Y>; ($timestep,$truechains,$rest)=split(/ /,$line); 
  foreach $i (1 .. $truechains-1) { $value=<D>; $value=strip($value); print N "$value "; }; 
  $value=<D>; $value=strip($value); print N "$value\n";
 }; 
 close(Y);
 close(N);
 close(D);
 `rm -f .$file`; 
}; 
print "\n";
