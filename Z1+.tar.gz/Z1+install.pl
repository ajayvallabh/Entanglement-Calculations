#! /usr/bin/perl

# (c) 30 march 2021 mk@mat.ethz.ch

# Copyright 2022 Martin Kroger
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#   http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

sub greenprint { print "\033[1;32;40m $_[0] \033[1;37;40m"; print "\n"; };
sub redprint   { print "\033[1;31;40m $_[0] \033[1;37;40m"; print "\n"; };

sub PUBLIC_DISTRIBUTION { @DIST=();
    $DIST[$#DIST+1] = "Z1+install.pl";
    $DIST[$#DIST+1] = "Z1+README.txt";
    $DIST[$#DIST+1] = "Z1+template.pl";
    $DIST[$#DIST+1] = "module-shared.f90";
    $DIST[$#DIST+1] = "module-output-formats.f90";
    $DIST[$#DIST+1] = "module-messages.f90";
    $DIST[$#DIST+1] = "module-folding.f90";
    $DIST[$#DIST+1] = "module-PPA.f90";
    $DIST[$#DIST+1] = "module-CPPA.f90";
    $DIST[$#DIST+1] = "module-license.f90";
    $DIST[$#DIST+1] = "module-main.f90";
    $DIST[$#DIST+1] = "Z1+import-lammps.pl";
    $DIST[$#DIST+1] = "Z1+rearrange.pl";
    $DIST[$#DIST+1] = "Z1+.ex";
    $DIST[$#DIST+1] = "LICENSE.txt"; 
    $DIST[$#DIST+1] = "NOTICE.txt"; 
    $DIST[$#DIST+1] = "Z1+.jar";
    $DIST[$#DIST+1] = ".benchmark-01.Z1";
    $DIST[$#DIST+1] = ".benchmark-02.Z1";
    $DIST[$#DIST+1] = ".benchmark-03.Z1";
    $DIST[$#DIST+1] = ".benchmark-04.Z1";
    $DIST[$#DIST+1] = ".benchmark-05.Z1";
    $DIST[$#DIST+1] = ".benchmark-06.Z1";
    $DIST[$#DIST+1] = ".benchmark-07.Z1";
    $DIST[$#DIST+1] = ".benchmark-08.Z1";
    $DIST[$#DIST+1] = ".benchmark-09.Z1";
    $DIST[$#DIST+1] = ".benchmark-10.Z1";
    $DIST[$#DIST+1] = ".benchmark-11.Z1";
    $DIST[$#DIST+1] = ".benchmark-12.Z1";
    $DIST[$#DIST+1] = ".benchmark-13.Z1";
    $DIST[$#DIST+1] = ".benchmark-14.Z1";
};

sub show_PUBLIC_DISTRIBUTION {
    PUBLIC_DISTRIBUTION;
    greenprint("\nThe public Z1+ distribution contains the following files:");
    foreach $dist (@DIST) { print "[Z1+] $dist\n"; }; 
};

sub PRIVATE_DISTRIBUTION { @DIST=();
    $DIST[$#DIST+1] = "Z1+install.pl";
    $DIST[$#DIST+1] = "Z1+README.txt";
    $DIST[$#DIST+1] = "Z1+template-mk.pl";
    $DIST[$#DIST+1] = "module-shared.f90";
    $DIST[$#DIST+1] = "module-output-formats.f90";
    $DIST[$#DIST+1] = "module-messages.f90";
    $DIST[$#DIST+1] = "module-folding.f90";
    $DIST[$#DIST+1] = "module-debug_pre.f90";
    $DIST[$#DIST+1] = "module-functions.f90";
    $DIST[$#DIST+1] = "module-debugging.f90";
    $DIST[$#DIST+1] = "module-developer.f90";
    $DIST[$#DIST+1] = "module-Z1.f90";
    $DIST[$#DIST+1] = "module-PPA.f90";
    $DIST[$#DIST+1] = "module-CPPA.f90";
    $DIST[$#DIST+1] = "module-license.f90";
    $DIST[$#DIST+1] = "module-main.f90";
    $DIST[$#DIST+1] = "module-mkseed.f90";
    $DIST[$#DIST+1] = "Z1+import-lammps.pl";
    $DIST[$#DIST+1] = "Z1+rearrange.pl";
    $DIST[$#DIST+1] = "Z1+README-PRIVATE.txt";
    $DIST[$#DIST+1] = "LICENSE.txt";
    $DIST[$#DIST+1] = "NOTICE.txt";
    $DIST[$#DIST+1] = "Z1+.jar";
}; 

sub show_PRIVATE_DISTRIBUTION {
    PRIVATE_DISTRIBUTION;
    greenprint("\nThe private Z1+ distribution contains the following files:");
    foreach $dist (@DIST) { print "[Z1+] $dist\n"; };
};

sub names { 
    $template = "Z1+template.pl";
    $final = "Z1+";
    $installation_directory = `pwd`; chomp $installation_directory;
    $code = "$installation_directory/Z1+.ex";
};

sub check_if_files_exist {
    PUBLIC_DISTRIBUTION; if ($ARGV[0]) { PRIVATE_DISTRIBUTION; }; 
    foreach $file (@DIST) {
        if (-s "$file") { } else { redprint("STOP. $file is missing\n"); exit; }; 
    }; 
    greenprint("\nThis Z1+ distribution is complete")
}; 

sub check_if_ex_exists {
    if (-s "Z1+.ex") { } else { redprint("Z1+.ex does not exist. contact mk\n"); exit; }; 
}; 

sub activate_debug { foreach $modname ("debug_pre","developer","debugging") { open(fp,">.use-$modname"); { print fp "use $modname\n"; }; close(fp); }; };
sub deactivate_debug { foreach $modname ("debug_pre","developer","debugging") { open(fp,">.use-$modname"); { print fp "!\n"; }; close(fp); }; };
sub write_license { open(I,">inc.Z1+license"); print I "licenseD=1\nlicenseM=02\nlicenseY=$Lyear\n"; close(I); };

sub compiling {
if ($ARGV[0] eq "mkdebug") {
    `rm -f Z1.ex`; 
    $Lyear = `date +"%Y"`; $Lyear+=100;
    open(I,">inc.Z1+email"); print I "EMAIL = \"mkdebug\""; close(I);
    write_license;
    activate_debug;
    print `ifort -O3 module-shared.f90 module-output-formats.f90 module-messages.f90 module-folding.f90 module-debug_pre.f90 module-functions.f90 module-debugging.f90 module-developer.f90 module-Z1.f90 module-PPA.f90 module-CPPA.f90 module-license.f90 module-main.f90 -o Z1+.ex`;
} elsif ($ARGV[0] eq "mk") {
    `rm -f Z1.ex`; 
    $Lyear = `date +"%Y"`; $Lyear+=100;
    open(I,">inc.Z1+email"); print I "EMAIL = \"mk\""; close(I);
    write_license;
    deactivate_debug;
    foreach $module ("shared","output-formats","messages","folding","functions","Z1","PPA","CPPA","license","main") {
        open(f,"<module-$module.f90"); @f=<f>; close(f); foreach $i (0 .. $#f) { if ($f[$i]=~/debug|develop/) { if ($f[$i]=~/public/) { } else { $f[$i]=""; }; }; }; open(f,">ifort-module-$module.f90"); print f @f; close(f);
    };
    print `ifort -O3 ifort-module-shared.f90 ifort-module-output-formats.f90 ifort-module-messages.f90 ifort-module-folding.f90 ifort-module-functions.f90 ifort-module-Z1.f90 ifort-module-PPA.f90 ifort-module-CPPA.f90 ifort-module-license.f90 ifort-module-main.f90 -o Z1+.ex`;
    `rm -f ifort-module*.f90`;
} elsif ($ARGV[0] eq "CPC") {
    `rm -f Z1.ex Z1+.tar.gz`; 
    $Lyear = `date +"%Y"`; $Lyear+=100;
    open(I,">inc.Z1+email"); print I "EMAIL = \"CPC\""; close(I);
    write_license;
    deactivate_debug;
    foreach $module ("shared","output-formats","messages","folding","functions","Z1","PPA","CPPA","license","main") {
        open(f,"<module-$module.f90"); @f=<f>; close(f); foreach $i (0 .. $#f) { if ($f[$i]=~/debug|develop/) { if ($f[$i]=~/public/) { } else { $f[$i]=""; }; }; };
        open(f,">ifort-module-$module.f90"); print f @f; close(f);
    };
    print `ifort -O3 -static-intel ifort-module-shared.f90 ifort-module-output-formats.f90 ifort-module-messages.f90 ifort-module-folding.f90 ifort-module-functions.f90 ifort-module-Z1.f90 ifort-module-PPA.f90 ifort-module-CPPA.f90 ifort-module-license.f90 ifort-module-main.f90 -o Z1+.ex`;
    PUBLIC_DISTRIBUTION; $TARSTRING = "tar -c -v -f Z1+.tar"; foreach $dist (@DIST) { if ("$dist" eq "module-Z1.f90") { } else { $TARSTRING.=" $dist"; }; }; `$TARSTRING; gzip Z1+.tar`;
    print "created Z1+.tar.gz for CPC\n";
} elsif ($ARGV[0]) {
    `rm -f Z1.ex Z1+.tar.gz`;
    $Lyear = `date +"%Y"`; $Lyear+=2;
    open(I,">inc.Z1+email"); print I "EMAIL = \"$ARGV[0]\""; close(I);
    write_license;
    deactivate_debug;
    foreach $module ("shared","output-formats","messages","folding","functions","Z1","PPA","CPPA","license","main") {
        open(f,"<module-$module.f90"); @f=<f>; close(f); foreach $i (0 .. $#f) { if ($f[$i]=~/debug|develop/) { if ($f[$i]=~/public/) { } else { $f[$i]=""; }; }; };
        open(f,">ifort-module-$module.f90"); print f @f; close(f);
    };
    print `ifort -O3 -static-intel ifort-module-shared.f90 ifort-module-output-formats.f90 ifort-module-messages.f90 ifort-module-folding.f90 ifort-module-functions.f90 ifort-module-Z1.f90 ifort-module-PPA.f90 ifort-module-CPPA.f90 ifort-module-license.f90 ifort-module-main.f90 -o Z1+.ex`;
    PUBLIC_DISTRIBUTION; $TARSTRING = "tar -c -v -f Z1+.tar"; foreach $dist (@DIST) { $TARSTRING.=" $dist"; }; `$TARSTRING; gzip Z1+.tar`;
    print "created Z1+.tar.gz for $ARGV[0]\n";
};
};

sub linking {
    if (!$ARGV[0]) { return; }; 
    greenprint("\ncompiling:");
    PRIVATE_DISTRIBUTION;  
    $ofiles="";
    foreach $dist (@DIST) {
        if (($dist=~/module/)&&($dist=~/$compiler/)) {
            print "linking $dist\n";
            $ofiles .= "$dist ";
        };
    };
    $ofiles .= "-o Z1+.ex";
    if ($compiler eq "gfortran") {
        print `$compiler -Ofast -ffree-line-length-none $ofiles`; 
    } elsif ($compiler eq "ifort") {
        print `$compiler -O3 $ofiles`;
    }; 
    greenprint("\ndone.");
};

sub create_parfile { 
    open(f,">Z1+parameters");
    print f "&parameters\n";
    print f "visualize = .False.\n";
    print f "movie = .False.\n";
    print f "self_entanglement = .False.\n";
    print f "benchmarks = .True.\n";
    print f "stats = .True.\n";
    print f "logfile = .True.\n";
    print f "basic_SP = .True.\n";
    print f "lmax_factor = 1.0\n";
    print f "thickness = 0.002\n";
    print f "user = '$user'\n";
    print f "debug = .False.\n";
    print f "/\n";
    close(f);
    greenprint("\nZ1+parameters contains:");
    print `cat Z1+parameters`; 
};

sub handle_clean { @DEL=();
    $DEL[$#DEL+1] = "Z1+parameters";
    $DEL[$#DEL+1] = "Lpp_values.dat";
    $DEL[$#DEL+1] = "N_values.dat";
    $DEL[$#DEL+1] = "Z_values.dat";
    $DEL[$#DEL+1] = "Ree_values.dat";
    $DEL[$#DEL+1] = "Z1+NODES.dat";
    $DEL[$#DEL+1] = "NODES-unfolded.dat";
    $DEL[$#DEL+1] = "Z_initconfiguration";
    $DEL[$#DEL+1] = "Z1+SP.dat";
    $DEL[$#DEL+1] = "PPA.dat";
    $DEL[$#DEL+1] = "PPA+.dat";     
    $DEL[$#DEL+1] = "Z1+summary.dat";
    $DEL[$#DEL+1] = "Z1+summary.html";
    $DEL[$#DEL+1] = "PPA-summary.dat";
    $DEL[$#DEL+1] = "PPA-summary.html";
    $DEL[$#DEL+1] = "PPA+summary.dat";
    $DEL[$#DEL+1] = "PPA+summary.html";
    foreach $filen (@DEL) { 
        if (-s "$filen") { print "[Z1+] removing $filen\n"; `rm -f $filen`; }; 
    }; 
    print "[Z1+] finished cleaning.\n";
}; 

sub check_perl_version {
    $perl = `which perl`; chomp $perl; 
    $perlversion = `$perl -v | head -1`; chomp $perlversion; 
};


sub create_final { 
    greenprint("\ncreating $final ...");
    open(fp1,"<$template");
    open(fp2,">$final");
    while (!eof(fp1)) {
        $line = <fp1>;
        if ($line=~/INSTALLATION-DIRECTORY/) {
            print fp2 "\$installation_directory = \"$installation_directory\";\n"; 
        } elsif ($line=~/INTERPRETER/) {
            print fp2 "#! $perl\n";
        } elsif ($line=~/USER/) { 
            print fp2 "\$user = \"$user\";\n";
        } elsif ($line=~/PERL/) {
            print fp2 "\$perl = \"$perl\";\n"; 
        } elsif ($line=~/COMPILERVERSION/) {
            print fp2 "    print \" , compiler $compiler_version\\n\";\n";
        } else { 
            print fp2 "$line";
        };
    }; 
    close(fp1);
    close(fp2);
    `chmod 700 $final`; 
    if (-s "Z1.ex")  { `chmod 700 Z1.ex`; }; 
    if (-s "Z1+.ex") { `chmod 700 Z1+.ex`; };  
    greenprint("done.");
};

sub check { 
    if (-s ".benchmark-01.Z1") { return; }; 
    if (-s "$template")        { return; }; 
    redprint("install Z1+ from within its installation directory\n"); exit;
}; 

sub check_compiler_ex { 
    if (!$ARGV[0]) { return; }; 
    $gfortran = `which gfortran`; chomp $gfortran; if (-s "$gfortran") { } else { $gfortran=0; }; 
    $ifort = `which ifort`; chomp $ifort; if (-s "$ifort") { } else { $ifort=0; }; 
    $compiler = "";
    if ($gfortran) {  
        $compiler = "gfortran";
    } elsif ($ifort) { 
        $compiler = "ifort"; 
    } else { 
        print("contact mk to receive an executable Z1+ or install gfortran or ifort"); exit;
    }; 
    print "using $compiler\n";
};

sub start_benchmarks { 
    create_parfile;
    greenprint("\n$code launched ..");
    print `$code`; 
    greenprint("\nZ1+ execution finished.");
};

if ($ARGV[0]) { $user = "$ARGV[0]"; } else { $user = "CPC"; };  
check_perl_version; 
check_compiler_ex;
show_PUBLIC_DISTRIBUTION;
check_if_files_exist;
compiling;
check_if_ex_exists;
names;
check;
start_benchmarks;
handle_clean;
create_final;
greenprint("\nZ1+ installation finished.\n\ncopy Z1+ to a location where it can be found. Do not start Z1+ from its installation directory.\n");
